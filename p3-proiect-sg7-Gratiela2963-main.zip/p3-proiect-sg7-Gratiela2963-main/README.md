[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/DqvRgdrh)
# Sistem de gestionare a unui cabinet medical
Oprișan Elena-Grațiela

## Descriere
Sistemul permite stocarea datelor despre pacienții cabinetului.
Medicul poate adăuga și șterge un pacient,poate accesa informații exclusiv despre pacienții săi înregistrați după nume și poate vizualiza informațiile pacientului(numele,diagnostic,dacă are asigurare sau nu ,cnp,nume prenume).
Voi oferi o scurtă prezentare a funcționalităților și a aspectelor-cheie ale codului.

--------Titlul și Butonul de Login/Logout:

Titlul "Medical Management System" este afișat în centrul ferestrei.
Butonul "Login" deschide un dialog pentru autentificare.
Butonul "Logout" deconectează utilizatorul curent.
Butoane pentru Vizualizare:

"View Patients" și "View Doctors" permit vizualizarea listelor de pacienți și medici.
"PROGRAMARE" deschide un dialog pentru programarea unei consultații.
"UTILIZATORI" permite vizualizarea numărului de pacienți și medici.

------Autentificare:

Se folosește un dialog de autentificare cu câmpuri pentru introducerea numelui de utilizator și a parolei.
Utilizatorii pot fi administrați cu roluri diferite (ADMINISTRATOR, MEDIC, PACIENT).
-Liste de Pacienți și Medici:

"Adaugare Pacient" și "Stergere Pacient" permit manipularea listei de pacienți(exclusiv medicilor).
"Adaugare Medic" și "Stergere Medic" permit manipularea listei de medici(exclusiv pacientilor).
"Refresh" actualizează afișarea listelor.

------Programare Consultație:

Utilizatorii pot programa consultații cu medici, specificând ID-ul medicului, data, ora, diagnosticul și tratamentul.

------Verificări de Permisiuni:

Există verificări pentru permisiuni în funcție de tipul de utilizator, astfel încât anumite acțiuni să fie permise doar pentru anumiți utilizatori.

-----Interfață pentru Utilizator Administrativ:

Utilizatorii cu rol de administrator pot vizualiza statistici despre numărul de pacienți și medici adăugați.

-----Aspect Grafic:

Interfața are un aspect organizat, cu butoane colorate pentru a evidenția acțiunile.

----Erori și Validare Input:

Există gestionare a erorilor și validare a input-ului pentru a preveni problemele legate de introducerea datelor.

## Obiective
-Implementarea unei structuri de date pentru a stoca informațiile pacienților

-Implementarea funcționalităților pentru a permite medicului să editeze informațiile pacientului

-Interfața intuitivă

-Efectuarea testelor pentru a identifica și corecta eventualele erori

-Setarea obiectivelor și monitorizarea obiectivelor
-Gestionarea versiunilor și revizuirilor

## Arhitectura


(![Screenshot 2023-11-02 191406](https://github.com/Programare-III-2023-2024/p3-proiect-sg7-Gratiela2963/assets/119081763/2ad65d31-5f8c-497f-a41c-65f5c05542bf)




## Functionalitati/Exemple utilizare
-controlul de acces permite diferite niveluri de permisiuni în funcție de tipul de utilizator (ADMINISTRATOR, MEDIC, PACIENT)

-useri cu acces exclusiv limitat

-actiuni specifice pentru fiecare tip de user

-login/logout


### Resurse
Markdown Guide, [Online] Available: https://www.markdownguide.org/basic-syntax/ [accesed: Mar 14, 1706]
