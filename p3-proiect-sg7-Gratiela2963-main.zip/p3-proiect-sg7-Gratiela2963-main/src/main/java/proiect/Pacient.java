package proiect;

public class Pacient extends Persoana {
    private String nrtel;
    private String diagnostic;
    private boolean areAsigurareSanatate;
    public Pacient(String nume, String prenume, long CNP, String nrTel2, String diagnostic, boolean areAsigurareSanatate) {
        super(nume, prenume, CNP);
        this.nrtel = nrTel2;
        this.diagnostic = diagnostic;
        this.areAsigurareSanatate = areAsigurareSanatate;
        
    }
    @Override
    public String toString() {
        return "Pacient [nume=" + getNume() +
               ", prenume=" + getPrenume() +
               ", CNP=" + getCNP() +
               ", nrtel=" + nrtel +
               ", diagnostic=" + diagnostic +
               ", areAsigurareSanatate=" + areAsigurareSanatate +
               "]";
    }

    public String getNrtel() {
        return nrtel;
    }

    public void setNrtel(String nrtel) {
        this.nrtel = nrtel;
    }

    public String getDiagnostic() {
        return diagnostic;
    }

    public void setDiagnostic(String diagnostic) {
        this.diagnostic = diagnostic;
    }

    public boolean isAreAsigurareSanatate() {
        return areAsigurareSanatate;
    }

    public void setAreAsigurareSanatate(boolean areAsigurareSanatate) {
        this.areAsigurareSanatate = areAsigurareSanatate;
    }
}

