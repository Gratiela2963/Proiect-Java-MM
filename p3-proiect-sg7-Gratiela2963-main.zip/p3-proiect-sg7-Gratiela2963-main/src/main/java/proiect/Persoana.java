package proiect;


public abstract class Persoana {
    protected String nume;
    protected String prenume;
    protected long CNP;

    public Persoana() {

    }

    public Persoana(String nume, String prenume, long CNP) {
        super();
        this.nume = nume;
        this.prenume = prenume;
        this.CNP = CNP;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public long getCNP() {
        return CNP;
    }

    public void setCNP(long cNP) {
        CNP = cNP;
    }
}


