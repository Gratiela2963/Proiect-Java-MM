package proiect;

import java.util.Scanner;

public class Main {
	 public static int numarPacienti = 0;
    private static ListaPacienti pacienti = new ListaPacienti();
    private static ListaMedici medici = new ListaMedici();
    private static Utilizator utilizatorCurent = null;
    private static Utilizator medicUser = new Utilizator("MEDIC123", "parola123", TipUtilizator.MEDIC);
    private static Utilizator pacientUser = new Utilizator("PACIENT456", "parola456", TipUtilizator.PACIENT);
    private static Utilizator adminUser = new Utilizator("ADMIN789", "parola789", TipUtilizator.ADMINISTRATOR);

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            // Adăugați un medic și un pacient pentru a avea date de test
            medici.adaugaMedic(new Medic("Medic1", "PrenumeMedic", 1234567890123L, 123456789, "ID123", "Cardiologie", "Cabinet123", 5));
           /// pacienti.adaugaPacient(new Pacient("Pacient1", "PrenumePacient", 9876543210123L, 987654321, "Diagnostic123", true));

            while (utilizatorCurent == null) {
                System.out.println("Introduceti username-ul: ");
                String username = scanner.nextLine();
                System.out.println("Introduceti parola: ");
                String parola = scanner.nextLine();

                // Verificați credențialele și setați utilizatorul curent
                utilizatorCurent = autentificare(username, parola, medicUser, pacientUser, adminUser);

                if (utilizatorCurent == null) {
                    System.out.println("Autentificare esuata. Incercati din nou.");
                }
            }

            do {
                // Afiseaza meniul corespunzator tipului de utilizator
                afiseazaMeniu(utilizatorCurent.getTip());

                System.out.println("0. Logout");
                System.out.print("Alege optiune: ");
                int optiune = scanner.nextInt();
                scanner.nextLine(); // Consuma newline ramas in buffer

                switch (optiune) {
                    case 0:
                        utilizatorCurent = null; // Deconectare utilizator
                        System.out.println("Deconectare cu succes.");
                        break;

                    case 1:
                        if (utilizatorCurent.getTip() == TipUtilizator.MEDIC) {
                            adaugaPacientDeLaTastatura(scanner);
                        } else {
                            System.out.println("Optiune nevalida pentru tipul de utilizator.");
                        }
                        break;
                    case 2:
                        if (utilizatorCurent.getTip() == TipUtilizator.MEDIC) {
                            stergePacientDeLaTastatura(scanner);
                        } else {
                            System.out.println("Optiune nevalida pentru tipul de utilizator.");
                        }
                        break;
                    case 3:
                        afiseazaPacienti();
                        break;
                    case 4:
                        if (utilizatorCurent.getTip() == TipUtilizator.PACIENT) {
                            adaugaMedicDeLaTastatura(scanner);
                        } else {
                            System.out.println("Optiune nevalida pentru tipul de utilizator.");
                        }
                        break;
                    case 5:
                        if (utilizatorCurent.getTip() == TipUtilizator.PACIENT) {
                            stergeMedicDeLaTastatura(scanner);
                        } else {
                            System.out.println("Optiune nevalida pentru tipul de utilizator.");
                        }
                        break;
                    case 6:
                        afiseazaMedici();
                        break;
                    case 7:
                        if (utilizatorCurent.getTip() == TipUtilizator.ADMINISTRATOR) {
                            afiseazaUtilizatori();
                        } else {
                            System.out.println("Optiune nevalida pentru tipul de utilizator.");
                        }
                        break;
                    case 8:
                        if (utilizatorCurent.getTip() == TipUtilizator.ADMINISTRATOR) {
                            afiseazaNumarPacienti();
                        } else {
                            System.out.println("Opțiune nevalidă pentru tipul de utilizator.");
                        }
                        break;
                    default:
                        System.out.println("Optiune invalida. Va rugam sa incercati din nou.");
                }
            } while (utilizatorCurent != null);
        }
    }
    private static Utilizator autentificare(String username, String parola, Utilizator... utilizatori) {
        for (Utilizator u : utilizatori) {
            if (u.getUsername().equals(username) && u.getParola().equals(parola)) {
                return u;
            }
        }
        return null;
    }

    private static void afiseazaUtilizatori() {
        System.out.println("Lista utilizatorilor:");
        medicUser.afiseazaInformatii();
        pacientUser.afiseazaInformatii();
        adminUser.afiseazaInformatii();
    }

    private static void afiseazaMeniu(TipUtilizator tipUtilizator) {
        if (tipUtilizator == TipUtilizator.MEDIC) {
            System.out.println("--------------MENIU MEDIC---------------------");
            System.out.println("1. Adauga pacient");
            System.out.println("2. Sterge pacient");
            System.out.println("3. Afiseaza pacienti");

        } else if (tipUtilizator == TipUtilizator.PACIENT) {
            System.out.println("--------------MENIU PACIENT---------------------");
            System.out.println("4. Adauga medic");
            System.out.println("5. Sterge medic");
            System.out.println("6. Afiseaza medici");

        } else if (tipUtilizator == TipUtilizator.ADMINISTRATOR) {
            System.out.println("--------------MENIU ADMINISTRATOR---------------------");
            System.out.println("7. Afiseaza utilizatori");
            System.out.println("8. Afișează numărul de pacienți");

        }
    }

    private static void afiseazaPacienti() {
        System.out.println("Lista pacientilor:");
        pacienti.afiseazaPacienti();
    }

    private static void afiseazaMedici() {
        System.out.println("Lista medicilor:");
        medici.afiseazaMedici();
    }

    public static void adaugaPacientDeLaTastatura(Scanner scanner) {
        System.out.print("Nume: ");
        String nume = scanner.nextLine();
        System.out.print("Prenume: ");
        String prenume = scanner.nextLine();
        System.out.print("CNP: ");
        long cnp = scanner.nextLong();
        scanner.nextLine(); // Consuma newline ramas in buffer
        System.out.print("Numar de telefon: ");
        String nrtel = scanner.nextLine();
        scanner.nextLine();
        System.out.print("Diagnostic: ");
        String diagnostic = scanner.nextLine();
        System.out.print("Are asigurare de sanatate? (true/false): ");
        boolean areAsigurare = scanner.nextBoolean();

        Pacient pacient = new Pacient(nume, prenume, cnp, nrtel, diagnostic, areAsigurare);
        pacienti.adaugaPacient(pacient);

        numarPacienti++; // Incrementați numărul de pacienți

        System.out.println("Pacient adaugat cu succes!");
      
    }

    private static void afiseazaNumarPacienti() {
        System.out.println("Numărul total de pacienți: " + ListaPacienti.getNumarPacienti());
    }


    public static void stergePacientDeLaTastatura(Scanner scanner) {
        System.out.print("Introduceti CNP-ul pacientului pe care doriti sa-l stergeti: ");
        long cnp = scanner.nextLong();
        pacienti.stergePacient(cnp);
        System.out.println("Pacient sters cu succes!");
    }

    public static void adaugaMedicDeLaTastatura(Scanner scanner) {
        System.out.print("Nume: ");
        String nume = scanner.nextLine();
        System.out.print("Prenume: ");
        String prenume = scanner.nextLine();
        System.out.print("CNP: ");
        long cnp = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Numar de telefon: ");
        int nrtel = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID: ");
        String id = scanner.nextLine();
        System.out.print("Specializare: ");
        String specializare = scanner.nextLine();
        System.out.print("Cabinet: ");
        String cabinet = scanner.nextLine();
        System.out.print("Experienta: ");
        int experienta = scanner.nextInt();

        Medic medic = new Medic(nume, prenume, cnp, nrtel, id, specializare, cabinet, experienta);
        medici.adaugaMedic(medic);

        System.out.println("Medic adaugat cu succes!");
    }

    public static void stergeMedicDeLaTastatura(Scanner scanner) {
        System.out.print("Introduceti ID-ul medicului pe care doriti sa-l stergeti: ");
        String id = scanner.nextLine();
        medici.stergeMedic(id);
        System.out.println("Medic sters cu succes!");
    }
}



//////