package proiect;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.LocalDateTime;
public class Medic extends Persoana {
    int nrtel;
    String ID;
    String specializare;
    String cabinet;
    int experienta;
    private Map<LocalDateTime, VizitaMedicala> schedule;
    public Medic() {
    	 
    }

    public Medic(String nume, String prenume, long CNP, int nrtel, String ID, String specializare, String cabinet, int experienta) {
        super(nume, prenume, CNP);
        this.nrtel = nrtel;
        this.ID = ID;
        this.specializare = specializare;
        this.cabinet = cabinet;
        this.experienta = experienta;
        this.schedule = new HashMap<>();
       
    }

   
    @Override
    public String toString() {
        return "Medic [nume=" + getNume() +
               ", prenume=" + getPrenume() +
               ", CNP=" + getCNP() +
               ", nrtel=" + nrtel +
               ", ID=" + ID +
               ", specializare=" + specializare +
               ", cabinet=" + cabinet +
               ", experienta=" + experienta +
               "]";
    }
   
    public int getNrtel() {
        return nrtel;
    }

    public void setNrtel(int nrtel) {
        this.nrtel = nrtel;
    }

    public String getID() {
        return ID;
    }

    public void setID(String iD) {
        ID = iD;
    }

    public String getSpecializare() {
        return specializare;
    }

    public void setSpecializare(String specializare) {
        this.specializare = specializare;
    }

    public String getCabinet() {
        return cabinet;
    }

    public void setCabinet(String cabinet) {
        this.cabinet = cabinet;
    }

    public int getExperienta() {
        return experienta;
    }

    public void setExperienta(int experienta) {
        this.experienta = experienta;
    }
    public void programareConsultatie(LocalDateTime dateTime, String diagnostic, String tratament) {
        // Verificăm dacă intervalul de programare este disponibil
        if (!schedule.containsKey(dateTime)) {
            // Creăm o nouă programare
            VizitaMedicala vizita = new VizitaMedicala(dateTime, diagnostic, tratament);
            schedule.put(dateTime, vizita);
            System.out.println("Consultația a fost programată cu succes.");
        } else {
            System.out.println("Intervalul este deja rezervat. Alegeți alt interval.");
        }
    }

    public Map<LocalDateTime, VizitaMedicala> getSchedule() {
        return schedule;
    }
}


