package proiect;

import java.util.ArrayList;
import java.util.List;

public class ListaPacienti {
    private static int numarPacienti = 0;
    private List<Pacient> pacienti;

    public ListaPacienti() {
        this.pacienti = new ArrayList<>();
    }

    public void adaugaPacient(Pacient pacient) {
        if (!pacienti.contains(pacient)) {
            pacienti.add(pacient);
            numarPacienti++;
        }
    }
    public List<Pacient> getListaPacienti() {
        return pacienti;
    }
    public void stergePacient(long cnp) {
        pacienti.removeIf(pacient -> pacient.getCNP() == cnp);
        numarPacienti--;
    }

    public void afiseazaPacienti() {
        for (Pacient pacient : pacienti) {
            System.out.println(pacient);
        }
    }

    public static int getNumarPacienti() {
        return numarPacienti;
    }
}