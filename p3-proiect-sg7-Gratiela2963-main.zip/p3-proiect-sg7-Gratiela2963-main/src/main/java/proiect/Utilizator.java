package proiect;

public class Utilizator {
    private String username;
    private String parola;
    private TipUtilizator tip;

    public Utilizator(String username, String parola, TipUtilizator tip) {
        this.username = username;
        this.parola = parola;
        this.tip = tip;
    }
    

    public void afiseazaInformatii() {
        System.out.println("Username: " + getUsername());
        System.out.println("Tip utilizator: " + getTip());
    }


    public String getUsername() {
        return username;
    }

    public String getParola() {
        return parola;
    }

    public TipUtilizator getTip() {
        return tip;
    }
}
