package proiect;

import java.time.LocalDateTime;

public class VizitaMedicala {
    private LocalDateTime dataVizitei;
    private String diagnostic;
    private String tratament;

    public VizitaMedicala(LocalDateTime dataVizitei, String diagnostic, String tratament) {
        this.dataVizitei = dataVizitei;
        this.diagnostic = diagnostic;
        this.tratament = tratament;
    }

    public LocalDateTime getDataVizitei() {
        return dataVizitei;
    }

    public void setDataVizitei(LocalDateTime dataVizitei) {
        this.dataVizitei = dataVizitei;
    }

    public String getDiagnostic() {
        return diagnostic;
    }

    public void setDiagnostic(String diagnostic) {
        this.diagnostic = diagnostic;
    }

    public String getTratament() {
        return tratament;
    }

    public void setTratament(String tratament) {
        this.tratament = tratament;
    }

    @Override
    public String toString() {
        return "VizitaMedicala [dataVizitei=" + dataVizitei + ", diagnostic=" + diagnostic + ", tratament=" + tratament + "]";
    }
}

////