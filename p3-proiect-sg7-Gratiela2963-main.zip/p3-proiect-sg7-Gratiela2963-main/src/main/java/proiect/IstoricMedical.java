package proiect;

import java.util.List;

public class IstoricMedical {
    private List<VizitaMedicala> viziteAnterioare;
    private String tratamenteAnterioare;

    public IstoricMedical(List<VizitaMedicala> viziteAnterioare, String tratamenteAnterioare) {
        this.viziteAnterioare = viziteAnterioare;
        this.tratamenteAnterioare = tratamenteAnterioare;
    }

    public List<VizitaMedicala> getViziteAnterioare() {
        return viziteAnterioare;
    }

    public void setViziteAnterioare(List<VizitaMedicala> viziteAnterioare) {
        this.viziteAnterioare = viziteAnterioare;
    }

    public String getTratamenteAnterioare() {
        return tratamenteAnterioare;
    }

    public void setTratamenteAnterioare(String tratamenteAnterioare) {
        this.tratamenteAnterioare = tratamenteAnterioare;
    }

    @Override
    public String toString() {
        return "IstoricMedical [viziteAnterioare=" + viziteAnterioare + ", tratamenteAnterioare=" + tratamenteAnterioare + "]";
    }
}
