package proiect;
import java.util.ArrayList;
import java.util.List;

public class ListaUtilizatori {
    private static List<Utilizator> utilizatori = new ArrayList<>();

    public static List<Utilizator> getUtilizatori() {
        return utilizatori;
    }

    public static void adaugaUtilizator(Utilizator utilizator) {
        utilizatori.add(utilizator);
    }

    public static void stergeUtilizator(Utilizator utilizator) {
        utilizatori.remove(utilizator);
    }
}