package proiect;

import java.util.ArrayList;
import java.util.List;

public class ListaMedici {
    private List<Medic> medici;

    public ListaMedici() {
        this.medici = new ArrayList<>();
    }

    public void adaugaMedic(Medic medic) {
        medici.add(medic);
    }

    public void stergeMedic(String id) {
        medici.removeIf(medic -> medic.getID().equals(id));
    }

    public List<Medic> getListaMedici() {
        return medici;
    }
    public void afiseazaMedici() {
        for (Medic medic : medici) {
            System.out.println(medic);
        }
    }
    public Medic getMedicById(String id) {
        for (Medic medic : medici) {
            if (medic.getID().equals(id)) {
                return medic;
            }
        }
        return null; // Return null if no medic with the specified ID is found
    }
}