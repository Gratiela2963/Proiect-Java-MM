package proiect;

public enum TipUtilizator {
    MEDIC,
    PACIENT,
    ADMINISTRATOR

}
