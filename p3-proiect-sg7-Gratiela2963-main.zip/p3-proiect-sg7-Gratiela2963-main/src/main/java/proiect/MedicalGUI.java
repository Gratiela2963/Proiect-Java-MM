package proiect;

import javax.swing.SwingUtilities;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;


public class MedicalGUI extends JFrame {
    private JFrame frame;
    private ListaPacienti pacienti;
    private ListaMedici medici;
    private Utilizator utilizatorCurent;
    public MedicalGUI() {
    	super("Medical GUI"); 
    setLayout(new FlowLayout(FlowLayout.CENTER));
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initialize();
    }
    public MedicalGUI(ListaPacienti pacienti, ListaMedici medici) {
        this.pacienti = pacienti;
        this.medici = medici;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("----Medical Management System----");
        frame.setBounds(100,100, 800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.getContentPane().add(panel, BorderLayout.CENTER);
        panel.setLayout(new GridLayout(5, 1));
        
        // Add a JLabel for the project title
        JLabel titleLabel = new JLabel("Medical Management System", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));  // Set the font for the title
        panel.add(titleLabel);


        JButton loginButton = new JButton("Login");
        JButton logoutButton = new JButton("Logout");
        JButton viewPatientsButton = new JButton("View Patients");
        JButton viewDoctorsButton = new JButton("View Doctors");
        JButton viewDataButton = new JButton("PROGRAMARE");
        JButton usersButton = new JButton("UTILIZATORI");
        loginButton.setBackground(Color.BLUE);  // Example color (you can use any color you like)
        logoutButton.setBackground(Color.RED);
        viewPatientsButton.setBackground(Color.GREEN);
        viewDoctorsButton.setBackground(Color.ORANGE);
        viewDataButton.setBackground(Color.CYAN);
        usersButton.setBackground(Color.YELLOW);
        panel.add(loginButton);
        panel.add(logoutButton);
        panel.add(viewPatientsButton);
        panel.add(viewDoctorsButton);
        panel.add(viewDataButton);
        panel.add(usersButton); 
        
        usersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (utilizatorCurent != null && utilizatorCurent.getTip() == TipUtilizator.ADMINISTRATOR) {
                    showUsersDialog();
                } else {
                    JOptionPane.showMessageDialog(frame, "You don't have permission to view users.");
                }
            }
        });
        
        viewDataButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Adaugă acțiunea pentru butonul "PROGRAMARE"
                if (utilizatorCurent != null && utilizatorCurent.getTip() == TipUtilizator.PACIENT) {
                    showScheduleDialog();
                } else {
                    JOptionPane.showMessageDialog(frame, "You don't have permission to schedule appointments.");
                }
            }
        });
        
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showLoginDialog();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                utilizatorCurent = null;
                JOptionPane.showMessageDialog(frame, "Logout successful.");
            }
        });

        viewPatientsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (utilizatorCurent != null) {
                    if (utilizatorCurent.getTip() == TipUtilizator.MEDIC) {
                        showPatientsList();
                    } else {
                        JOptionPane.showMessageDialog(frame, "You don't have permission to view patients.");
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please log in first.");
                }
            }
        });

        viewDoctorsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (utilizatorCurent != null) {
                    if (utilizatorCurent.getTip() == TipUtilizator.PACIENT) {
                        showDoctorsList();
                    } else {
                        JOptionPane.showMessageDialog(frame, "You don't have permission to view doctors.");
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please log in first.");
                }
            }
        });
        
       

        frame.setVisible(true);
    }

    
    private void showUsersDialog() {
        // Obține numărul de pacienți și medici adăugați
        int numarPacienti = pacienti.getListaPacienti().size();
        int numarMedici = medici.getListaMedici().size();

        // Afișează dialogul cu informațiile despre utilizatori
        String message = "Numar de pacienti adaugati: " + numarPacienti + "\n" +
                         "Numar de medici adaugati: " + numarMedici;

        JOptionPane.showMessageDialog(frame, message, "Utilizatori", JOptionPane.INFORMATION_MESSAGE);
    }
    private void showLoginDialog() {
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        Object[] message = {
                "Username:", usernameField,
                "Password:", passwordField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Login", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            utilizatorCurent = autentificare(username, password);
            if (utilizatorCurent != null) {
                JOptionPane.showMessageDialog(frame, "Login successful.");
            } else {
                JOptionPane.showMessageDialog(frame, "Login failed. Please try again.");
            }
        }
    }

    private Utilizator autentificare(String username, String parola) {
        if (username.equals("ADMIN789") && parola.equals("parola789")) {
            return new Utilizator("admin", "admin", TipUtilizator.ADMINISTRATOR);
        } else if (username.equals("MEDIC123") && parola.equals("parola123")) {
            return new Utilizator("doctor", "doctor", TipUtilizator.MEDIC);
        } else if (username.equals("PACIENT456") && parola.equals("parola456")) {
            return new Utilizator("patient", "patient", TipUtilizator.PACIENT);
        }

        return null; 
    }

    private void showPatientsList() {
        // Evitați NullPointerException
        if (pacienti == null) {
            JOptionPane.showMessageDialog(frame, "Lista pacienților nu este inițializată.");
            return;
        }

        JFrame patientFrame = new JFrame("Patients List");
        patientFrame.setBounds(200, 200, 600, 400);

        JPanel patientPanel = new JPanel();
        patientFrame.getContentPane().add(patientPanel, BorderLayout.CENTER);
        patientPanel.setLayout(new BorderLayout());

        JTextArea patientTextArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(patientTextArea);

        patientPanel.add(scrollPane, BorderLayout.CENTER);

        // Adăugați butoanele pentru adăugare, ștergere și vizualizare
        JButton addButton = new JButton("Adaugare Pacient");
        JButton deleteButton = new JButton("Stergere Pacient");
        JButton viewButton = new JButton("Refresh");

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);

        patientPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Ascultător pentru butonul de adăugare
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddPatientDialog();
                refreshPatientsList(patientTextArea);
            }
        });

        // Ascultător pentru butonul de ștergere
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showDeletePatientDialog();
                refreshPatientsList(patientTextArea);
            }
        });

        // Ascultător pentru butonul de vizualizare
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshPatientsList(patientTextArea);
            }
        });

        patientFrame.setVisible(true);
    }
    
    private void showAddPatientDialog() {
        JTextField numeField = new JTextField();
        JTextField prenumeField = new JTextField();
        JTextField cnpField = new JTextField();
        JTextField nrTelField = new JTextField();
        JTextField diagnosticField = new JTextField();
        JTextField asigurareField = new JTextField();

        Object[] message = {
                "Nume:", numeField,
                "Prenume:", prenumeField,
                "CNP:", cnpField,
                "Numar Telefon:", nrTelField,
                "Diagnostic:", diagnosticField,
                "Are Asigurare:", asigurareField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Adaugare Pacient", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
        	String nume = numeField.getText();
        	String prenume = prenumeField.getText();
        	String cnpString = cnpField.getText(); // Read CNP as String
        	long cnp = Long.parseLong(cnpString); // Convert CNP to long
        	String nrTel = nrTelField.getText();
        	String diagnostic = diagnosticField.getText();
        	boolean areAsigurare = Boolean.parseBoolean(asigurareField.getText());

            // Adăugare pacient în listă
        	Pacient pacient = new Pacient(nume, prenume, cnp, nrTel, diagnostic, areAsigurare);
        	pacienti.adaugaPacient(pacient);
        }
    }

    private void showDeletePatientDialog() {
        JTextField cnpField = new JTextField();

        Object[] message = {
                "CNP Pacient:", cnpField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Stergere Pacient", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String cnp = cnpField.getText();

            // Stergere pacient după CNP
            pacienti.stergePacient(Long.parseLong(cnp));
        }
    }

    private void refreshPatientsList(JTextArea patientTextArea) {
        patientTextArea.setText(""); // Șterge textul anterior

        // Afiseaza pacientii in TextArea
        for (Pacient pacient : pacienti.getListaPacienti()) {
            patientTextArea.append(pacient.toString() + "\n");
        }
    }
    
    private void showDoctorsList() {
        if (medici == null) {
            JOptionPane.showMessageDialog(frame, "Lista medicilor nu este inițializată.");
            return;
        }
        
        JFrame doctorFrame = new JFrame("Doctors List");
        doctorFrame.setBounds(200, 200, 600, 400);

        JPanel doctorPanel = new JPanel();
        doctorFrame.getContentPane().add(doctorPanel, BorderLayout.CENTER);
        doctorPanel.setLayout(new BorderLayout());

        JTextArea doctorTextArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(doctorTextArea);

        doctorPanel.add(scrollPane, BorderLayout.CENTER);

        // Adăugați butoanele pentru adăugare, ștergere și vizualizare
        JButton addButton = new JButton("Adaugare Medic");
        JButton deleteButton = new JButton("Stergere Medic");
        JButton viewButton = new JButton("Refresh");

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        JButton scheduleButton = new JButton("Programează-te");
        JButton adminButton = new JButton("View Administration");
        
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);

        doctorPanel.add(buttonPanel, BorderLayout.SOUTH);

  
        
        
        scheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (utilizatorCurent != null && utilizatorCurent.getTip() == TipUtilizator.PACIENT) {
                    showScheduleDialog();
                } else {
                    JOptionPane.showMessageDialog(frame, "You don't have permission to schedule appointments.");
                }
            }
        });

        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (utilizatorCurent != null && utilizatorCurent.getTip() == TipUtilizator.ADMINISTRATOR) {
                    showAdministrationView();
                } else {
                    JOptionPane.showMessageDialog(frame, "You don't have permission to view administration.");
                }
            }
        });  
        
        
        // Ascultător pentru butonul de adăugare
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddDoctorDialog();
                refreshDoctorsList(doctorTextArea);
            }
        });

        // Ascultător pentru butonul de ștergere
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showDeleteDoctorDialog();
                refreshDoctorsList(doctorTextArea);
            }
        });

        // Ascultător pentru butonul de vizualizare
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshDoctorsList(doctorTextArea);
            }
        });

        doctorFrame.setVisible(true);
    }

    protected void showAdministrationView() {
		// TODO Auto-generated method stub
		
	}
	private void showAddDoctorDialog() {
        JTextField numeField = new JTextField();
        JTextField prenumeField = new JTextField();
        JTextField cnpField = new JTextField();
        JTextField nrTelField = new JTextField();
        JTextField idField = new JTextField();
        JTextField specializareField = new JTextField();
        JTextField cabinetField = new JTextField();
        JTextField experientaField = new JTextField();

        Object[] message = {
                "Nume:", numeField,
                "Prenume:", prenumeField,
                "CNP:", cnpField,
                "Numar Telefon:", nrTelField,
                "ID:", idField,
                "Specializare:", specializareField,
                "Cabinet:", cabinetField,
                "Experienta:", experientaField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Adaugare Medic", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            try {
                String nume = numeField.getText();
                String prenume = prenumeField.getText();
                long cnp = Long.parseLong(cnpField.getText());
                int nrtel = Integer.parseInt(nrTelField.getText());
                String id = idField.getText();
                String specializare = specializareField.getText();
                String cabinet = cabinetField.getText();
                int experienta = Integer.parseInt(experientaField.getText());

                // Adăugare medic în listă
                Medic medic = new Medic(nume, prenume, cnp, nrtel, id, specializare, cabinet, experienta);
                medici.adaugaMedic(medic);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid numeric values.");
            }
        }
    }

    private void showDeleteDoctorDialog() {
        JTextField idField = new JTextField();

        Object[] message = {
                "ID Medic:", idField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Stergere Medic", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            try {
                String id = idField.getText();
                medici.stergeMedic(id);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(frame, "Invalid input. Please enter a valid numeric ID.");
            }
        }
    }



    private void refreshDoctorsList(JTextArea doctorTextArea) {
        doctorTextArea.setText(""); // Șterge textul anterior

        // Afișează medicii în TextArea
        for (Medic medic : medici.getListaMedici()) {
            doctorTextArea.append(medic.toString() + "\n");
        }
    }
    

    private void showScheduleDialog() {
        JTextField doctorIdField = new JTextField();
        JTextField dateField = new JTextField();
        JTextField timeField = new JTextField();
        JTextField diagnosticField = new JTextField();
        JTextField tratamentField = new JTextField();

        Object[] message = {
                "ID Medic:", doctorIdField,
                "Data (yyyy-MM-dd):", dateField,
                "Ora (HH:mm):", timeField,
                "Diagnostic:", diagnosticField,
                "Tratament:", tratamentField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Programare Consultație", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            try {
                String doctorId = doctorIdField.getText();
                String date = dateField.getText();
                String time = timeField.getText();
                String diagnostic = diagnosticField.getText();
                String tratament = tratamentField.getText();

                // Find the selected doctor by ID
                Medic selectedMedic = medici.getMedicById(doctorId);

                if (selectedMedic != null) {
                    // Parse date and time
                    LocalDateTime dateTime = LocalDateTime.parse(date + "T" + time);

                    // Schedule the appointment
                    selectedMedic.programareConsultatie(dateTime, diagnostic, tratament);

                    JOptionPane.showMessageDialog(frame, "Consultația a fost programată cu succes.");
                } else {
                    JOptionPane.showMessageDialog(frame, "Medicul cu ID-ul specificat nu există.");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(frame, "Input invalid. Asigurați-vă că ați introdus datele corect.");
            }
        }
    }
 

    public static void main(String[] args) {
    	
    	EntityManagerFactory emf = Persistence.createEntityManagerFactory("myPersistence");
    	 SwingUtilities.invokeLater(new Runnable() {
    	        public void run() {
    	            ListaPacienti pacienti = new ListaPacienti();
    	            ListaMedici medici = new ListaMedici();
    	            MedicalGUI app = new MedicalGUI(pacienti, medici);
    	            app.setLocationRelativeTo(null);
    	            app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	            app.setVisible(true);
            }
        });
    }
}
